package com.meuapp.editor

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val TextTrackColor = Color(0xFF2EC4B6)
private val AudioTrackColor = Color(0xFF3DDC84)
private val VoiceTrackColor = Color(0xFFFF9F1C)

@Composable
fun Timeline(
    vm: EditorViewModel,
    onSeek: (Long) -> Unit,
    onOpenTextTool: () -> Unit
) {
    val density = LocalDensity.current.density
    val dpPerSec = 56f * vm.zoom
    val totalSec = maxOf(vm.totalMs, 6000L) / 1000f
    val contentWidth = (dpPerSec * totalSec + 140f).dp
    val hScroll = rememberScrollState()
    val vScroll = rememberScrollState()
    var viewport by remember { mutableIntStateOf(0) }

    fun msToDp(ms: Long) = (ms / 1000f * dpPerSec).dp
    fun pxToMs(px: Float): Long =
        (px / density / dpPerSec * 1000f).toLong().coerceIn(0L, vm.totalMs)

    // Segue o cursor durante a reprodução
    LaunchedEffect(vm.playheadMs, vm.isPlaying) {
        if (vm.isPlaying) {
            val x = (vm.playheadMs / 1000f * dpPerSec * density).toInt()
            if (x < hScroll.value || x > hScroll.value + viewport - 80) {
                hScroll.scrollTo((x - viewport / 3).coerceAtLeast(0))
            }
        }
    }

    Box(
        Modifier
            .fillMaxWidth()
            .height(176.dp)
            .background(Panel)
            .clipToBounds()
            .onSizeChanged { viewport = it.width }
            .horizontalScroll(hScroll)
    ) {
        Column(
            Modifier
                .width(contentWidth)
                .verticalScroll(vScroll)
        ) {
            // ---- Régua (toque ou arraste para navegar) ----
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(26.dp)
                    .pointerInput(dpPerSec, vm.totalMs) {
                        detectTapGestures { off -> onSeek(pxToMs(off.x)) }
                    }
                    .pointerInput(dpPerSec, vm.totalMs) {
                        detectHorizontalDragGestures { change, _ -> onSeek(pxToMs(change.position.x)) }
                    }
            ) {
                val step = when {
                    vm.zoom < 0.7f -> 10
                    vm.zoom < 1.4f -> 5
                    vm.zoom < 3f -> 2
                    else -> 1
                }
                var s = 0
                while (s <= totalSec.toInt()) {
                    Box(
                        Modifier
                            .offset(x = msToDp(s * 1000L))
                            .width(1.dp)
                            .height(8.dp)
                            .align(Alignment.BottomStart)
                            .background(TextDim)
                    )
                    Text(
                        "%d:%02d".format(s / 60, s % 60),
                        color = TextDim,
                        fontSize = 9.sp,
                        modifier = Modifier.offset(x = msToDp(s * 1000L) + 3.dp, y = 2.dp)
                    )
                    s += step
                }
            }

            // ---- Faixa de vídeo ----
            Box(Modifier.fillMaxWidth().height(62.dp).padding(vertical = 2.dp)) {
                vm.clips.forEachIndexed { i, c ->
                    val start = vm.clipStartMs(i)
                    val selected = vm.selectedClipId == c.id
                    val thumb = vm.thumbs[c.id]
                    Box(
                        Modifier
                            .offset(x = msToDp(start))
                            .width(msToDp(c.outDurationMs) - 2.dp)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Panel2)
                            .then(
                                if (selected) Modifier.border(2.dp, Accent2, RoundedCornerShape(8.dp))
                                else Modifier
                            )
                            .pointerInput(c.id, dpPerSec) {
                                detectTapGestures { off ->
                                    vm.selectClip(c.id)
                                    onSeek(start + (off.x / density / dpPerSec * 1000f).toLong())
                                }
                            }
                    ) {
                        if (thumb != null) {
                            Image(
                                bitmap = thumb,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize().alpha(0.75f)
                            )
                        }
                        val speedLabel = if (c.speed != 1f) " • %.2gx".format(c.speed) else ""
                        Text(
                            c.name + speedLabel,
                            color = Color.White,
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .background(Color(0x99000000))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
                if (vm.clips.isEmpty()) {
                    Text(
                        "Toque em Adicionar para importar vídeos",
                        color = TextDim,
                        fontSize = 12.sp,
                        modifier = Modifier.align(Alignment.CenterStart).padding(start = 12.dp)
                    )
                }
            }

            // ---- Faixa de texto ----
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(28.dp)
                    .padding(vertical = 2.dp)
            ) {
                vm.texts.forEach { t ->
                    val sel = vm.selectedTextId == t.id
                    Box(
                        Modifier
                            .offset(x = msToDp(t.startMs))
                            .width(msToDp((t.endMs - t.startMs).coerceAtLeast(300L)))
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(6.dp))
                            .background(TextTrackColor)
                            .then(if (sel) Modifier.border(2.dp, Color.White, RoundedCornerShape(6.dp)) else Modifier)
                            .pointerInput(t.id) {
                                detectTapGestures {
                                    vm.selectText(t.id)
                                    vm.tool = Tool.TEXT
                                    onOpenTextTool()
                                }
                            },
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            "T  " + t.text, color = Color.Black, fontSize = 10.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )
                    }
                }
                if (vm.texts.isEmpty()) {
                    Text("Texto", color = TextDim, fontSize = 10.sp, modifier = Modifier.padding(start = 6.dp))
                }
            }

            // ---- Faixas de áudio ----
            if (vm.audios.isEmpty()) {
                Box(Modifier.fillMaxWidth().height(28.dp).padding(vertical = 2.dp)) {
                    Text("Áudio", color = TextDim, fontSize = 10.sp, modifier = Modifier.padding(start = 6.dp))
                }
            }
            vm.audios.forEach { a ->
                val sel = vm.selectedAudioId == a.id
                Box(Modifier.fillMaxWidth().height(28.dp).padding(vertical = 2.dp)) {
                    Box(
                        Modifier
                            .width(msToDp(minOf(a.durationMs, vm.totalMs.coerceAtLeast(1000L))))
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (a.isVoice) VoiceTrackColor else AudioTrackColor)
                            .then(if (sel) Modifier.border(2.dp, Color.White, RoundedCornerShape(6.dp)) else Modifier)
                            .pointerInput(a.id) {
                                detectTapGestures {
                                    vm.selectAudio(a.id)
                                    vm.tool = if (a.isVoice) Tool.VOICE else Tool.MUSIC
                                }
                            },
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            "♪  " + a.name, color = Color.Black, fontSize = 10.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        // ---- Cursor (linha vermelha) ----
        Box(
            Modifier
                .offset(x = msToDp(vm.playheadMs))
                .width(2.dp)
                .height(400.dp)
                .background(Color(0xFFFF3B5C))
        )
    }
}
