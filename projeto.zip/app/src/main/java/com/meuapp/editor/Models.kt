package com.meuapp.editor

import android.net.Uri

enum class Aspect(val label: String, val ratio: Float?) {
    ORIGINAL("Original", null),
    SQUARE("1:1", 1f),
    PORTRAIT("9:16", 9f / 16f),
    WIDE("16:9", 16f / 9f),
    FOUR_FIVE("4:5", 0.8f)
}

enum class TextFont(val label: String, val family: String) {
    SANS("Moderna", "sans-serif"),
    SERIF("Clássica", "serif"),
    MONO("Código", "monospace"),
    CURSIVE("Manuscrita", "cursive"),
    CONDENSED("Condensada", "sans-serif-condensed")
}

enum class TextAnim(val label: String) {
    NONE("Nenhuma"),
    FADE("Aparecer"),
    SLIDE("Subir")
}

enum class TextPos(val label: String, val y: Float) {
    TOP("Topo", 0.7f),
    CENTER("Centro", 0f),
    BOTTOM("Base", -0.7f)
}

enum class Tool { NONE, TRIM, SPEED, ROTATE, COLOR, VOLUME, CROP, TEXT, MUSIC, VOICE }

data class Clip(
    val id: Long,
    val uri: Uri,
    val name: String,
    val sourceDurationMs: Long,
    val width: Int,
    val height: Int,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = sourceDurationMs,
    val speed: Float = 1f,
    val rotation: Int = 0,
    val flipH: Boolean = false,
    val flipV: Boolean = false,
    val brightness: Float = 0f,   // -1..1
    val contrast: Float = 0f,     // -1..1
    val saturation: Float = 0f,   // -1..1
    val volume: Float = 1f,       // 0..2
    val aspect: Aspect = Aspect.ORIGINAL
) {
    val outDurationMs: Long
        get() = ((trimEndMs - trimStartMs) / speed).toLong().coerceAtLeast(1L)
}

data class TextItem(
    val id: Long,
    val text: String,
    val startMs: Long,
    val endMs: Long,
    val color: Int = 0xFFFFFFFF.toInt(),
    val size: Float = 64f,
    val font: TextFont = TextFont.SANS,
    val bold: Boolean = true,
    val anim: TextAnim = TextAnim.FADE,
    val pos: TextPos = TextPos.BOTTOM
)

data class AudioItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val volume: Float = 1f,
    val isVoice: Boolean = false
)

enum class Quality(val label: String, val factor: Float) {
    LOW("Econômica", 0.6f),
    MEDIUM("Equilibrada", 1f),
    HIGH("Alta", 1.6f)
}

data class ExportSettings(
    val height: Int = 1080,          // lado menor: 720, 1080 ou 2160
    val fps: Int = 30,
    val quality: Quality = Quality.MEDIUM,
    val audioOnly: Boolean = false
) {
    val bitrate: Int
        get() {
            val base = when {
                height >= 2160 -> 35_000_000f
                height >= 1080 -> 10_000_000f
                else -> 5_000_000f
            }
            val fpsFactor = if (fps >= 60) 1.5f else 1f
            return (base * quality.factor * fpsFactor).toInt()
        }
}

sealed class ExportState {
    object Idle : ExportState()
    data class Running(val progress: Int) : ExportState()
    data class Done(val message: String) : ExportState()
    data class Failed(val message: String) : ExportState()
}
