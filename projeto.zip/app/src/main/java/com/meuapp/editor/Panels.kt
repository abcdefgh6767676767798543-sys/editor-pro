package com.meuapp.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun toolTitle(t: Tool) = when (t) {
    Tool.TRIM -> "Cortar"
    Tool.SPEED -> "Velocidade"
    Tool.ROTATE -> "Girar e espelhar"
    Tool.COLOR -> "Cores"
    Tool.VOLUME -> "Volume"
    Tool.CROP -> "Recortar / proporção"
    Tool.TEXT -> "Texto"
    Tool.MUSIC -> "Música e áudios"
    Tool.VOICE -> "Gravar voz"
    Tool.NONE -> ""
}

private fun speedText(s: Float): String =
    "%.2f".format(s).trimEnd('0').trimEnd('.') + "x"

@Composable
fun ToolPanel(
    vm: EditorViewModel,
    onPickAudio: () -> Unit,
    onToggleRecord: () -> Unit,
    onEditText: (TextItem?) -> Unit,
    onExtractAudio: () -> Unit
) {
    val clip = vm.selectedClip
    val needsClip = vm.tool in listOf(
        Tool.TRIM, Tool.SPEED, Tool.ROTATE, Tool.COLOR, Tool.VOLUME, Tool.CROP
    )

    Column(
        Modifier
            .fillMaxWidth()
            .background(Panel)
            .heightIn(max = 230.dp)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 8.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(toolTitle(vm.tool), color = Color.White, fontSize = 14.sp)
            IconButton(onClick = { vm.tool = Tool.NONE }) {
                Icon(Icons.Rounded.Close, contentDescription = "Fechar", tint = TextDim)
            }
        }

        if (needsClip && clip == null) {
            Text(
                "Toque em um clipe na linha do tempo para selecioná-lo.",
                color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp)
            )
            return@Column
        }

        when (vm.tool) {
            Tool.TRIM -> clip?.let { c ->
                Column(Modifier.padding(horizontal = 16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Início ${fmt(c.trimStartMs)}", color = Color.White, fontSize = 12.sp)
                        Text("Fim ${fmt(c.trimEndMs)}", color = Color.White, fontSize = 12.sp)
                    }
                    RangeSlider(
                        value = c.trimStartMs.toFloat()..c.trimEndMs.toFloat(),
                        onValueChange = { r ->
                            val s = r.start.toLong()
                            val e = r.endInclusive.toLong()
                            if (e - s >= 300) vm.setTrim(c.id, s, e)
                        },
                        valueRange = 0f..c.sourceDurationMs.toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = Accent2, activeTrackColor = Accent, inactiveTrackColor = Panel2
                        )
                    )
                    Text(
                        "Duração do trecho: ${fmt(c.outDurationMs)}  (original: ${fmt(c.sourceDurationMs)})",
                        color = TextDim, fontSize = 11.sp
                    )
                }
            }

            Tool.SPEED -> clip?.let { c ->
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f).forEach { s ->
                        Chip(speedText(s), c.speed == s) { vm.editClip(c.id, true) { it.copy(speed = s) } }
                    }
                }
                SliderRow(
                    "Velocidade (abaixo de 1x = câmera lenta)",
                    c.speed, 0.25f..4f, speedText(c.speed)
                ) { v -> vm.editClip(c.id) { it.copy(speed = (Math.round(v * 20f) / 20f)) } }
            }

            Tool.ROTATE -> clip?.let { c ->
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Chip("Girar 90° (${c.rotation}°)", false) {
                        vm.editClip(c.id, true) { it.copy(rotation = (it.rotation + 90) % 360) }
                    }
                    Chip("Espelhar ↔", c.flipH) { vm.editClip(c.id, true) { it.copy(flipH = !it.flipH) } }
                    Chip("Espelhar ↕", c.flipV) { vm.editClip(c.id, true) { it.copy(flipV = !it.flipV) } }
                    Chip("Zerar", false) {
                        vm.editClip(c.id, true) { it.copy(rotation = 0, flipH = false, flipV = false) }
                    }
                }
            }

            Tool.COLOR -> clip?.let { c ->
                SliderRow("Brilho", c.brightness, -1f..1f, "%d".format((c.brightness * 100).toInt())) { v ->
                    vm.editClip(c.id) { it.copy(brightness = v) }
                }
                SliderRow("Contraste", c.contrast, -1f..1f, "%d".format((c.contrast * 100).toInt())) { v ->
                    vm.editClip(c.id) { it.copy(contrast = v) }
                }
                SliderRow("Saturação", c.saturation, -1f..1f, "%d".format((c.saturation * 100).toInt())) { v ->
                    vm.editClip(c.id) { it.copy(saturation = v) }
                }
                Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Zerar cores", false) {
                        vm.editClip(c.id, true) { it.copy(brightness = 0f, contrast = 0f, saturation = 0f) }
                    }
                    Chip("Vívido", false) {
                        vm.editClip(c.id, true) { it.copy(brightness = 0.05f, contrast = 0.2f, saturation = 0.4f) }
                    }
                    Chip("P&B", false) {
                        vm.editClip(c.id, true) { it.copy(saturation = -1f) }
                    }
                }
            }

            Tool.VOLUME -> clip?.let { c ->
                SliderRow("Volume do clipe", c.volume, 0f..2f, "${(c.volume * 100).toInt()}%") { v ->
                    vm.editClip(c.id) { it.copy(volume = v) }
                }
                Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Mudo", c.volume == 0f) { vm.editClip(c.id, true) { it.copy(volume = 0f) } }
                    Chip("100%", c.volume == 1f) { vm.editClip(c.id, true) { it.copy(volume = 1f) } }
                    Chip("Extrair áudio (M4A)", false, onExtractAudio)
                }
            }

            Tool.CROP -> clip?.let { c ->
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Aspect.values().forEach { a ->
                        Chip(a.label, c.aspect == a) { vm.editClip(c.id, true) { it.copy(aspect = a) } }
                    }
                }
                Text(
                    "Recorta as bordas para a proporção escolhida (ex.: 9:16 para Reels e TikTok).",
                    color = TextDim, fontSize = 11.sp, modifier = Modifier.padding(16.dp, 8.dp)
                )
            }

            Tool.TEXT -> {
                val t = vm.selectedText
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Chip("＋ Novo texto", false) { onEditText(null) }
                    if (t != null) {
                        Chip("Editar", false) { onEditText(t) }
                        Chip("Excluir", false) { vm.deleteSelected() }
                    }
                }
                if (t != null && vm.totalMs > 0) {
                    Column(Modifier.padding(horizontal = 16.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Aparece em ${fmt(t.startMs)}", color = Color.White, fontSize = 12.sp)
                            Text("Some em ${fmt(t.endMs)}", color = Color.White, fontSize = 12.sp)
                        }
                        RangeSlider(
                            value = t.startMs.toFloat()..t.endMs.toFloat().coerceAtMost(vm.totalMs.toFloat()),
                            onValueChange = { r ->
                                val s = r.start.toLong()
                                val e = r.endInclusive.toLong()
                                if (e - s >= 300) vm.upsertTextQuiet(t.copy(startMs = s, endMs = e))
                            },
                            valueRange = 0f..vm.totalMs.toFloat(),
                            colors = SliderDefaults.colors(
                                thumbColor = Accent2, activeTrackColor = Accent, inactiveTrackColor = Panel2
                            )
                        )
                    }
                } else if (t == null) {
                    Text(
                        "O texto aparece no ponto onde está a linha vermelha. Toque no texto na timeline para ajustar o tempo.",
                        color = TextDim, fontSize = 11.sp, modifier = Modifier.padding(16.dp, 8.dp)
                    )
                }
            }

            Tool.MUSIC -> {
                Row(Modifier.padding(horizontal = 16.dp)) { Chip("＋ Importar áudio do celular", false, onPickAudio) }
                AudioList(vm, voice = false)
                Text(
                    "A música começa junto com o vídeo e é cortada no final dele.",
                    color = TextDim, fontSize = 11.sp, modifier = Modifier.padding(16.dp, 8.dp)
                )
            }

            Tool.VOICE -> {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(if (vm.recording) Color(0xFFFF3B5C) else Accent)
                            .clickable(onClick = onToggleRecord),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            if (vm.recording) Icons.Rounded.Stop else Icons.Rounded.Mic,
                            contentDescription = "Gravar", tint = Color.White
                        )
                    }
                    Text(
                        if (vm.recording) "Gravando… toque para parar" else "Toque para gravar sua voz",
                        color = Color.White, fontSize = 13.sp
                    )
                }
                AudioList(vm, voice = true)
            }

            Tool.NONE -> {}
        }
    }
}

@Composable
private fun AudioList(vm: EditorViewModel, voice: Boolean) {
    vm.audios.filter { it.isVoice == voice }.forEach { a ->
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                a.name, color = Color.White, fontSize = 12.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.width(90.dp)
            )
            Box(Modifier.weight(1f)) {
                androidx.compose.material3.Slider(
                    value = a.volume, valueRange = 0f..2f,
                    onValueChange = { v -> vm.editAudio(a.id) { it.copy(volume = v) } },
                    colors = SliderDefaults.colors(
                        thumbColor = Accent2, activeTrackColor = Accent, inactiveTrackColor = Panel2
                    )
                )
            }
            Text("${(a.volume * 100).toInt()}%", color = TextDim, fontSize = 11.sp)
            IconButton(onClick = {
                vm.selectAudio(a.id); vm.deleteSelected()
            }) { Icon(Icons.Rounded.Delete, contentDescription = "Remover", tint = TextDim) }
        }
    }
}
