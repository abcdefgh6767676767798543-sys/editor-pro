package com.meuapp.editor

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CallSplit
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Crop
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Undo
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.Presentation
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EditorTheme {
                EditorApp()
            }
        }
    }
}

// ---------- Utilitários do player ----------

private fun previewEffects(c: Clip): List<Effect> {
    val list = mutableListOf<Effect>()
    if (c.rotation != 0 || c.flipH || c.flipV) {
        list += ScaleAndRotateTransformation.Builder()
            .setRotationDegrees(c.rotation.toFloat())
            .setScale(if (c.flipH) -1f else 1f, if (c.flipV) -1f else 1f)
            .build()
    }
    c.aspect.ratio?.let {
        list += Presentation.createForAspectRatio(it, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
    }
    if (c.brightness != 0f) list += Brightness(c.brightness)
    if (c.contrast != 0f) list += Contrast(c.contrast)
    if (c.saturation != 0f) list += HslAdjustment.Builder().adjustSaturation(c.saturation * 100f).build()
    return list
}

private fun applyClip(player: ExoPlayer, c: Clip?) {
    if (c == null) return
    player.playbackParameters = PlaybackParameters(c.speed)
    player.volume = c.volume.coerceIn(0f, 1f)
    player.setVideoEffects(previewEffects(c))
}

private fun seekGlobal(player: ExoPlayer, vm: EditorViewModel, ms: Long) {
    var start = 0L
    vm.clips.forEachIndexed { i, c ->
        val end = start + c.outDurationMs
        if (ms < end || i == vm.clips.lastIndex) {
            val local = (ms - start).coerceIn(0L, c.outDurationMs)
            player.seekTo(i, (local * c.speed).toLong())
            applyClip(player, c)
            vm.playheadMs = start + local
            return
        }
        start = end
    }
}

private fun displayName(ctx: Context, uri: Uri): String {
    try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
    } catch (_: Exception) {
    }
    return uri.lastPathSegment ?: "Áudio"
}

// ---------- Tela principal ----------

@Composable
fun EditorApp(vm: EditorViewModel = viewModel()) {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build() }

    var showExport by remember { mutableStateOf(false) }
    var exportAudioOnly by remember { mutableStateOf(false) }
    var showTextDialog by remember { mutableStateOf(false) }
    var editingText by remember { mutableStateOf<TextItem?>(null) }

    // --- seletores de arquivo ---
    val pickVideos = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(20)
    ) { uris -> vm.addClips(uris) }

    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            vm.addAudio(uri, displayName(ctx, uri))
        }
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.startRecording() else vm.message = "Permissão do microfone negada."
    }

    fun toggleRecord() {
        if (vm.recording) {
            vm.stopRecording()
        } else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            vm.startRecording()
        } else {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    fun launchVideoPicker() {
        pickVideos.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
    }

    // --- player: ciclo de vida e sincronização com a timeline ---
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                applyClip(player, vm.clips.getOrNull(player.currentMediaItemIndex))
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    player.pause()
                    vm.playheadMs = vm.totalMs
                }
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    val sourceKey = vm.clips.map { Triple(it.uri, it.trimStartMs, it.trimEndMs) }
    LaunchedEffect(sourceKey) {
        delay(120) // evita recarregar a cada movimento do controle deslizante
        if (vm.clips.isEmpty()) {
            player.clearMediaItems()
            vm.playheadMs = 0L
            return@LaunchedEffect
        }
        val items = vm.clips.map { c ->
            MediaItem.Builder()
                .setUri(c.uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(c.trimStartMs)
                        .setEndPositionMs(c.trimEndMs)
                        .build()
                )
                .build()
        }
        val wasPlaying = player.isPlaying
        val keep = vm.playheadMs
        player.setMediaItems(items)
        player.prepare()
        seekGlobal(player, vm, keep.coerceIn(0L, vm.totalMs))
        player.playWhenReady = wasPlaying
    }

    val renderKey = vm.clips.map {
        listOf(it.speed, it.rotation, it.flipH, it.flipV, it.brightness, it.contrast, it.saturation, it.volume, it.aspect)
    }
    LaunchedEffect(renderKey) {
        applyClip(player, vm.clips.getOrNull(player.currentMediaItemIndex))
    }

    LaunchedEffect(player) {
        while (true) {
            vm.isPlaying = player.isPlaying
            if (player.isPlaying) {
                val i = player.currentMediaItemIndex
                val c = vm.clips.getOrNull(i)
                if (c != null) {
                    vm.playheadMs = vm.clipStartMs(i) + (player.currentPosition / c.speed).toLong()
                }
            }
            delay(40)
        }
    }

    LaunchedEffect(vm.message) {
        vm.message?.let {
            Toast.makeText(ctx, it, Toast.LENGTH_LONG).show()
            vm.message = null
        }
    }

    BackHandler(enabled = vm.tool != Tool.NONE) { vm.tool = Tool.NONE }

    fun togglePlay() {
        if (vm.clips.isEmpty()) return
        if (player.isPlaying) {
            player.pause()
        } else {
            if (vm.playheadMs >= vm.totalMs - 100) seekGlobal(player, vm, 0L)
            player.play()
        }
    }

    fun selectToolClip(t: Tool) {
        vm.tool = if (vm.tool == t) Tool.NONE else t
        val clipTool = t in listOf(Tool.TRIM, Tool.SPEED, Tool.ROTATE, Tool.COLOR, Tool.VOLUME, Tool.CROP)
        if (clipTool && vm.selectedClip == null && vm.clips.isNotEmpty()) {
            var start = 0L
            for (c in vm.clips) {
                val end = start + c.outDurationMs
                if (vm.playheadMs < end) { vm.selectClip(c.id); break }
                start = end
            }
            if (vm.selectedClip == null) vm.selectClip(vm.clips.last().id)
        }
    }

    // ---------- Layout ----------
    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .systemBarsPadding()
    ) {
        // Barra superior
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.VideoLibrary, contentDescription = null, tint = Accent2)
            Spacer(Modifier.width(8.dp))
            Text("Editor Pro", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { vm.undo() }, enabled = vm.canUndo) {
                Icon(
                    Icons.Rounded.Undo, contentDescription = "Desfazer",
                    tint = if (vm.canUndo) Color.White else Color(0xFF55556A)
                )
            }
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(AccentBrush)
                    .clickable {
                        if (vm.clips.isEmpty()) vm.message = "Adicione um vídeo primeiro."
                        else { exportAudioOnly = false; showExport = true }
                    }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.FileDownload, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Exportar", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        // Pré-visualização
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                factory = { c ->
                    PlayerView(c).apply {
                        useController = false
                        this.player = player
                    }
                },
                modifier = Modifier.fillMaxSize().clickable { togglePlay() }
            )
            // Prévia aproximada dos textos (o resultado final é desenhado na exportação)
            vm.texts.filter { vm.playheadMs >= it.startMs && vm.playheadMs < it.endMs }.forEach { t ->
                val align = when (t.pos) {
                    TextPos.TOP -> Alignment.TopCenter
                    TextPos.CENTER -> Alignment.Center
                    TextPos.BOTTOM -> Alignment.BottomCenter
                }
                Text(
                    t.text,
                    color = Color(t.color),
                    fontSize = (t.size * 0.33f).sp,
                    fontWeight = if (t.bold) FontWeight.Bold else FontWeight.Normal,
                    fontFamily = when (t.font) {
                        TextFont.SERIF -> FontFamily.Serif
                        TextFont.MONO -> FontFamily.Monospace
                        TextFont.CURSIVE -> FontFamily.Cursive
                        else -> FontFamily.SansSerif
                    },
                    modifier = Modifier.align(align).padding(24.dp)
                )
            }
            if (vm.clips.isEmpty()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(AccentBrush)
                            .clickable { launchVideoPicker() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = "Adicionar", tint = Color.White, modifier = Modifier.size(36.dp))
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("Importar vídeos da galeria", color = Color.White, fontSize = 14.sp)
                }
            } else if (!vm.isPlaying) {
                Box(
                    Modifier.size(56.dp).clip(CircleShape).background(Color(0x66000000)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = "Tocar", tint = Color.White, modifier = Modifier.size(34.dp))
                }
            }
        }

        // Linha de controle: play, tempo, mover, zoom
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { togglePlay() }) {
                Icon(
                    if (vm.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = "Tocar/Pausar", tint = Color.White
                )
            }
            Text(
                "${fmt(vm.playheadMs)} / ${fmt(vm.totalMs)}",
                color = Color.White, fontSize = 12.sp
            )
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { vm.moveSelected(-1) }) {
                Icon(Icons.Rounded.ChevronLeft, contentDescription = "Mover clipe para trás", tint = TextDim)
            }
            IconButton(onClick = { vm.moveSelected(1) }) {
                Icon(Icons.Rounded.ChevronRight, contentDescription = "Mover clipe para frente", tint = TextDim)
            }
            IconButton(onClick = { vm.zoom = (vm.zoom / 1.5f).coerceAtLeast(0.4f) }) {
                Icon(Icons.Rounded.ZoomOut, contentDescription = "Diminuir zoom", tint = TextDim)
            }
            IconButton(onClick = { vm.zoom = (vm.zoom * 1.5f).coerceAtMost(8f) }) {
                Icon(Icons.Rounded.ZoomIn, contentDescription = "Aumentar zoom", tint = TextDim)
            }
        }

        // Linha do tempo
        Timeline(
            vm = vm,
            onSeek = { ms -> seekGlobal(player, vm, ms) },
            onOpenTextTool = {}
        )

        // Painel da ferramenta ativa
        if (vm.tool != Tool.NONE) {
            ToolPanel(
                vm = vm,
                onPickAudio = { pickAudio.launch(arrayOf("audio/*")) },
                onToggleRecord = { toggleRecord() },
                onEditText = { t -> editingText = t; showTextDialog = true },
                onExtractAudio = {
                    if (vm.clips.isEmpty()) vm.message = "Adicione um vídeo primeiro."
                    else { exportAudioOnly = true; showExport = true }
                }
            )
        }

        // Barra de ferramentas
        Row(
            Modifier
                .fillMaxWidth()
                .background(Bg)
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            ToolButton(Icons.Rounded.Add, "Adicionar", false) { launchVideoPicker() }
            ToolButton(Icons.Rounded.CallSplit, "Dividir", false) { vm.splitAtPlayhead() }
            ToolButton(Icons.Rounded.ContentCut, "Cortar", vm.tool == Tool.TRIM) { selectToolClip(Tool.TRIM) }
            ToolButton(Icons.Rounded.Speed, "Velocidade", vm.tool == Tool.SPEED) { selectToolClip(Tool.SPEED) }
            ToolButton(Icons.Rounded.RotateRight, "Girar", vm.tool == Tool.ROTATE) { selectToolClip(Tool.ROTATE) }
            ToolButton(Icons.Rounded.Tune, "Cores", vm.tool == Tool.COLOR) { selectToolClip(Tool.COLOR) }
            ToolButton(Icons.Rounded.VolumeUp, "Volume", vm.tool == Tool.VOLUME) { selectToolClip(Tool.VOLUME) }
            ToolButton(Icons.Rounded.Crop, "Recortar", vm.tool == Tool.CROP) { selectToolClip(Tool.CROP) }
            ToolButton(Icons.Rounded.TextFields, "Texto", vm.tool == Tool.TEXT) { selectToolClip(Tool.TEXT) }
            ToolButton(Icons.Rounded.MusicNote, "Música", vm.tool == Tool.MUSIC) { selectToolClip(Tool.MUSIC) }
            ToolButton(Icons.Rounded.Mic, "Voz", vm.tool == Tool.VOICE) { selectToolClip(Tool.VOICE) }
            ToolButton(Icons.Rounded.ContentCopy, "Duplicar", false) { vm.duplicateSelected() }
            ToolButton(Icons.Rounded.Delete, "Excluir", false) { vm.deleteSelected() }
        }
    }

    if (showTextDialog) {
        TextEditorDialog(
            initial = editingText,
            vm = vm,
            onDismiss = { showTextDialog = false; editingText = null }
        )
    }
    if (showExport) {
        ExportDialog(
            vm = vm,
            startAudioOnly = exportAudioOnly,
            onDismiss = { showExport = false }
        )
    }
}

@Composable
private fun ToolButton(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .width(68.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = if (selected) Accent2 else Color.White, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(3.dp))
        Text(label, color = if (selected) Accent2 else TextDim, fontSize = 10.sp, maxLines = 1)
    }
}
