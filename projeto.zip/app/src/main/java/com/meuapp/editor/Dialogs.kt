package com.meuapp.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

private val Swatches = listOf(
    0xFFFFFFFF, 0xFF000000, 0xFFFFEB3B, 0xFFFF3B5C, 0xFFFF9F1C,
    0xFF3DDC84, 0xFF00C8FF, 0xFF7C5CFF, 0xFFFF5CAD
).map { it.toInt() }

@Composable
private fun SectionLabel(text: String) {
    Text(text, color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
}

@Composable
fun TextEditorDialog(initial: TextItem?, vm: EditorViewModel, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial?.text ?: "") }
    var color by remember { mutableStateOf(initial?.color ?: Swatches[0]) }
    var size by remember { mutableStateOf(initial?.size ?: 64f) }
    var font by remember { mutableStateOf(initial?.font ?: TextFont.SANS) }
    var bold by remember { mutableStateOf(initial?.bold ?: true) }
    var anim by remember { mutableStateOf(initial?.anim ?: TextAnim.FADE) }
    var pos by remember { mutableStateOf(initial?.pos ?: TextPos.BOTTOM) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(22.dp), color = Panel) {
            Column(
                Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp)
            ) {
                Text(
                    if (initial == null) "Novo texto / legenda" else "Editar texto",
                    color = Color.White, fontSize = 17.sp
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = text, onValueChange = { text = it },
                    label = { Text("Digite o texto") },
                    modifier = Modifier.fillMaxWidth()
                )

                SectionLabel("Cor")
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Swatches.forEach { c ->
                        Box(
                            Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(c))
                                .border(
                                    if (c == color) 3.dp else 1.dp,
                                    if (c == color) Accent2 else Color.Gray,
                                    CircleShape
                                )
                                .clickable { color = c }
                        )
                    }
                }

                SliderRowPlain("Tamanho", size, 32f..160f, "${size.toInt()}") { size = it }

                SectionLabel("Fonte")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextFont.values().forEach { f -> Chip(f.label, font == f) { font = f } }
                    Chip("Negrito", bold) { bold = !bold }
                }

                SectionLabel("Animação de entrada")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextAnim.values().forEach { a -> Chip(a.label, anim == a) { anim = a } }
                }

                SectionLabel("Posição")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextPos.values().forEach { p -> Chip(p.label, pos == p) { pos = p } }
                }

                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.weight(1f)) { Chip("Cancelar", false, onDismiss) }
                    Box(Modifier.weight(1f)) {
                        Chip("Salvar", true) {
                            if (text.isNotBlank()) {
                                val base = initial ?: vm.newText(text)
                                vm.upsertText(
                                    base.copy(
                                        text = text.trim(), color = color, size = size,
                                        font = font, bold = bold, anim = anim, pos = pos
                                    )
                                )
                                vm.tool = Tool.TEXT
                                onDismiss()
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SliderRowPlain(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>,
    valueText: String, onChange: (Float) -> Unit
) {
    Column {
        SectionLabel("$label: $valueText")
        androidx.compose.material3.Slider(
            value = value, onValueChange = onChange, valueRange = range
        )
    }
}

@Composable
fun ExportDialog(vm: EditorViewModel, startAudioOnly: Boolean, onDismiss: () -> Unit) {
    var height by remember { mutableStateOf(1080) }
    var fps by remember { mutableStateOf(30) }
    var quality by remember { mutableStateOf(Quality.MEDIUM) }
    var audioOnly by remember { mutableStateOf(startAudioOnly) }
    val state = vm.exportState
    val running = state is ExportState.Running

    Dialog(
        onDismissRequest = { if (!running) { vm.resetExport(); onDismiss() } },
        properties = DialogProperties(dismissOnBackPress = !running, dismissOnClickOutside = !running)
    ) {
        Surface(shape = RoundedCornerShape(22.dp), color = Panel) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(18.dp)) {
                Text("Exportar", color = Color.White, fontSize = 18.sp)

                when (state) {
                    is ExportState.Idle -> {
                        val s = ExportSettings(height, fps, quality, audioOnly)
                        SectionLabel("Tipo")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Chip("Vídeo MP4", !audioOnly) { audioOnly = false }
                            Chip("Só áudio (M4A)", audioOnly) { audioOnly = true }
                        }
                        if (!audioOnly) {
                            SectionLabel("Resolução (lado menor)")
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Chip("720p", height == 720) { height = 720 }
                                Chip("1080p", height == 1080) { height = 1080 }
                                Chip("4K", height == 2160) { height = 2160 }
                            }
                            if (height == 2160) {
                                Text(
                                    "4K só funciona se o celular suportar. Nunca passa da resolução do vídeo original.",
                                    color = TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                            SectionLabel("Quadros por segundo")
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Chip("30 FPS", fps == 30) { fps = 30 }
                                Chip("60 FPS", fps == 60) { fps = 60 }
                            }
                            Text(
                                "60 FPS só mantém 60 se o vídeo original já tiver 60.",
                                color = TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp)
                            )
                            SectionLabel("Qualidade")
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Quality.values().forEach { q -> Chip(q.label, quality == q) { quality = q } }
                            }
                            val mbps = s.bitrate / 1_000_000f
                            val mb = s.bitrate / 8f * (vm.totalMs / 1000f) / 1_000_000f
                            Text(
                                "Taxa de bits: %.1f Mbps  •  Tamanho estimado: ~%.0f MB".format(mbps, mb),
                                color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                        Spacer(Modifier.height(18.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Box(Modifier.weight(1f)) { Chip("Cancelar", false) { onDismiss() } }
                            Box(Modifier.weight(1f)) { Chip("Exportar", true) { vm.startExport(s) } }
                        }
                    }

                    is ExportState.Running -> {
                        Spacer(Modifier.height(16.dp))
                        Text("Exportando… ${state.progress}%", color = Color.White, fontSize = 14.sp)
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { state.progress / 100f },
                            modifier = Modifier.fillMaxWidth(),
                            color = Accent2, trackColor = Panel2
                        )
                        Text(
                            "Mantenha o app aberto até terminar.",
                            color = TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)
                        )
                        Spacer(Modifier.height(16.dp))
                        Chip("Cancelar exportação", false) { vm.cancelExport() }
                    }

                    is ExportState.Done -> {
                        Spacer(Modifier.height(16.dp))
                        Text("Pronto! ✔", color = Color(0xFF3DDC84), fontSize = 16.sp)
                        Text(state.message, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                        Spacer(Modifier.height(16.dp))
                        Chip("Concluir", true) { vm.resetExport(); onDismiss() }
                    }

                    is ExportState.Failed -> {
                        Spacer(Modifier.height(16.dp))
                        Text("Não deu certo", color = Color(0xFFFF3B5C), fontSize = 16.sp)
                        Text(state.message, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Chip("Tentar de novo", true) { vm.resetExport() }
                            Chip("Fechar", false) { vm.resetExport(); onDismiss() }
                        }
                    }
                }
            }
        }
    }
}
