package com.meuapp.editor

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.graphics.Typeface
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.FrameDropEffect
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import com.google.common.collect.ImmutableList
import java.io.File
import kotlin.math.min

/** Texto com tempo de início/fim e animação, desenhado sobre o vídeo exportado. */
@UnstableApi
class TimedTextOverlay(private val item: TextItem) : TextOverlay() {

    private val span: SpannableString = SpannableString(item.text).apply {
        val end = length
        setSpan(ForegroundColorSpan(item.color), 0, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        setSpan(AbsoluteSizeSpan(item.size.toInt(), false), 0, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        setSpan(TypefaceSpan(item.font.family), 0, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (item.bold) setSpan(StyleSpan(Typeface.BOLD), 0, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    override fun getText(presentationTimeUs: Long): SpannableString = span

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val ms = presentationTimeUs / 1000
        val builder = OverlaySettings.Builder()
        if (ms < item.startMs || ms >= item.endMs) {
            return builder.setAlphaScale(0f).build()
        }
        val p = ((ms - item.startMs) / 500f).coerceIn(0f, 1f)
        var y = item.pos.y
        var alpha = 1f
        when (item.anim) {
            TextAnim.NONE -> {}
            TextAnim.FADE -> alpha = p
            TextAnim.SLIDE -> {
                alpha = p
                y -= 0.15f * (1f - p)
            }
        }
        return builder.setAlphaScale(alpha).setBackgroundFrameAnchor(0f, y).build()
    }
}

@UnstableApi
object ExportBuilder {

    private fun clipItem(c: Clip, audioOnly: Boolean): EditedMediaItem {
        val mediaItem = MediaItem.Builder()
            .setUri(c.uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(c.trimStartMs)
                    .setEndPositionMs(c.trimEndMs)
                    .build()
            )
            .build()

        val video = mutableListOf<Effect>()
        if (c.speed != 1f) video += SpeedChangeEffect(c.speed)
        if (c.rotation != 0 || c.flipH || c.flipV) {
            video += ScaleAndRotateTransformation.Builder()
                .setRotationDegrees(c.rotation.toFloat())
                .setScale(if (c.flipH) -1f else 1f, if (c.flipV) -1f else 1f)
                .build()
        }
        c.aspect.ratio?.let {
            video += Presentation.createForAspectRatio(it, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
        }
        if (c.brightness != 0f) video += Brightness(c.brightness)
        if (c.contrast != 0f) video += Contrast(c.contrast)
        if (c.saturation != 0f) video += HslAdjustment.Builder().adjustSaturation(c.saturation * 100f).build()

        val audio = mutableListOf<AudioProcessor>()
        if (c.speed != 1f) audio += SonicAudioProcessor().apply { setSpeed(c.speed) }
        if (c.volume != 1f) audio += volumeProcessor(c.volume)

        return EditedMediaItem.Builder(mediaItem)
            .setRemoveVideo(audioOnly)
            .setEffects(Effects(audio, video))
            .build()
    }

    private fun volumeProcessor(volume: Float): ChannelMixingAudioProcessor {
        val mixer = ChannelMixingAudioProcessor()
        for (ch in 1..2) {
            mixer.putChannelMixingMatrix(ChannelMixingMatrix.create(ch, ch).scaleBy(volume))
        }
        return mixer
    }

    private fun audioItem(a: AudioItem, totalMs: Long): EditedMediaItem {
        val end = min(a.durationMs, totalMs).coerceAtLeast(100L)
        val mediaItem = MediaItem.Builder()
            .setUri(a.uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(0)
                    .setEndPositionMs(end)
                    .build()
            )
            .build()
        val processors = mutableListOf<AudioProcessor>()
        if (a.volume != 1f) processors += volumeProcessor(a.volume)
        return EditedMediaItem.Builder(mediaItem)
            .setRemoveVideo(true)
            .setEffects(Effects(processors, emptyList()))
            .build()
    }

    /** Resolução final: limita ao tamanho do vídeo original para não "esticar" a imagem. */
    private fun targetShortSide(clips: List<Clip>, wanted: Int): Int {
        val first = clips.first()
        val swap = first.rotation % 180 != 0
        val w = if (swap) first.height else first.width
        val h = if (swap) first.width else first.height
        val short = if (first.aspect.ratio != null) {
            // com recorte de proporção, usa o lado menor do vídeo original como teto
            min(w, h)
        } else min(w, h)
        return if (short > 0) min(wanted, short) else wanted
    }

    private fun isPortraitOutput(first: Clip): Boolean {
        first.aspect.ratio?.let { return it < 1f }
        val swap = first.rotation % 180 != 0
        val w = if (swap) first.height else first.width
        val h = if (swap) first.width else first.height
        return h > w
    }

    fun build(
        clips: List<Clip>,
        texts: List<TextItem>,
        audios: List<AudioItem>,
        s: ExportSettings
    ): Composition {
        val totalMs = clips.sumOf { it.outDurationMs }
        val videoSeq = EditedMediaItemSequence.Builder(
            *clips.map { clipItem(it, s.audioOnly) }.toTypedArray()
        ).build()

        val sequences = mutableListOf(videoSeq)
        for (a in audios) {
            sequences += EditedMediaItemSequence.Builder(audioItem(a, totalMs)).build()
        }

        val videoEffects = mutableListOf<Effect>()
        if (!s.audioOnly) {
            val first = clips.first()
            val short = targetShortSide(clips, s.height)
            videoEffects += if (isPortraitOutput(first)) {
                Presentation.createForWidth(short)
            } else {
                Presentation.createForHeight(short)
            }
            if (s.fps <= 30) {
                videoEffects += FrameDropEffect.createDefaultFrameDropEffect(30f)
            }
            if (texts.isNotEmpty()) {
                val overlays = ImmutableList.builder<TextureOverlay>().apply {
                    texts.forEach { add(TimedTextOverlay(it)) }
                }.build()
                videoEffects += OverlayEffect(overlays)
            }
        }

        return Composition.Builder(sequences)
            .setEffects(Effects(emptyList(), videoEffects))
            .build()
    }
}

object MediaSaver {
    /** Copia o arquivo exportado para a galeria (Movies/EditorPro ou Music/EditorPro). */
    fun saveToGallery(context: Context, file: File, audioOnly: Boolean): Uri? {
        val resolver = context.contentResolver
        val name = "EditorPro_" + System.currentTimeMillis() + if (audioOnly) ".m4a" else ".mp4"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, if (audioOnly) "audio/mp4" else "video/mp4")
            put(
                MediaStore.MediaColumns.RELATIVE_PATH,
                (if (audioOnly) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES) + "/EditorPro"
            )
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val collection = if (audioOnly) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        }
        val uri = resolver.insert(collection, values) ?: return null
        resolver.openOutputStream(uri)?.use { out ->
            file.inputStream().use { it.copyTo(out) }
        } ?: return null
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        return uri
    }
}
