package com.meuapp.editor

import android.app.Application
import android.media.MediaMetadataRetriever
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private data class Snapshot(
    val clips: List<Clip>,
    val texts: List<TextItem>,
    val audios: List<AudioItem>
)

@UnstableApi
class EditorViewModel(app: Application) : AndroidViewModel(app) {

    val clips = mutableStateListOf<Clip>()
    val texts = mutableStateListOf<TextItem>()
    val audios = mutableStateListOf<AudioItem>()
    val thumbs = mutableStateMapOf<Long, ImageBitmap>()

    var selectedClipId by mutableStateOf<Long?>(null)
    var selectedTextId by mutableStateOf<Long?>(null)
    var selectedAudioId by mutableStateOf<Long?>(null)
    var tool by mutableStateOf(Tool.NONE)
    var playheadMs by mutableLongStateOf(0L)
    var zoom by mutableFloatStateOf(1f)
    var isPlaying by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)

    var exportState by mutableStateOf<ExportState>(ExportState.Idle)
    var recording by mutableStateOf(false)

    private var idGen = 1L
    private fun nextId() = idGen++

    private val undoStack = ArrayDeque<Snapshot>()
    private var lastCommit = 0L

    val totalMs: Long get() = clips.sumOf { it.outDurationMs }
    val selectedClip: Clip? get() = clips.firstOrNull { it.id == selectedClipId }
    val selectedText: TextItem? get() = texts.firstOrNull { it.id == selectedTextId }
    val canUndo: Boolean get() = undoStack.isNotEmpty()

    // ---------- Desfazer ----------
    fun commit() {
        undoStack.addLast(Snapshot(clips.toList(), texts.toList(), audios.toList()))
        if (undoStack.size > 40) undoStack.removeFirst()
        lastCommit = System.currentTimeMillis()
    }

    /** Usado em sliders: agrupa vários movimentos em um único passo de "desfazer". */
    private fun commitThrottled() {
        if (System.currentTimeMillis() - lastCommit > 900) commit()
    }

    fun undo() {
        val s = undoStack.removeLastOrNull() ?: return
        clips.clear(); clips.addAll(s.clips)
        texts.clear(); texts.addAll(s.texts)
        audios.clear(); audios.addAll(s.audios)
        if (clips.none { it.id == selectedClipId }) selectedClipId = clips.firstOrNull()?.id
        lastCommit = 0L
    }

    // ---------- Seleção ----------
    fun selectClip(id: Long?) { selectedClipId = id; selectedTextId = null; selectedAudioId = null }
    fun selectText(id: Long?) { selectedTextId = id; selectedClipId = null; selectedAudioId = null }
    fun selectAudio(id: Long?) { selectedAudioId = id; selectedClipId = null; selectedTextId = null }

    fun clipStartMs(index: Int): Long = clips.take(index).sumOf { it.outDurationMs }

    // ---------- Importação ----------
    private fun readInfo(uri: Uri): Triple<Long, Int, Int>? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(getApplication<Application>(), uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) Triple(dur, h, w) else Triple(dur, w, h)
        } catch (e: Exception) {
            null
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    fun addClips(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            commit()
            for (uri in uris) {
                val info = withContext(Dispatchers.IO) { readInfo(uri) }
                if (info == null || info.first <= 0L) {
                    message = "Não foi possível abrir um dos vídeos."
                    continue
                }
                val clip = Clip(
                    id = nextId(), uri = uri, name = "Clipe ${clips.size + 1}",
                    sourceDurationMs = info.first, width = info.second, height = info.third
                )
                clips.add(clip)
                if (selectedClipId == null) selectClip(clip.id)
                loadThumb(clip)
            }
        }
    }

    private fun loadThumb(clip: Clip) {
        viewModelScope.launch(Dispatchers.IO) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(getApplication<Application>(), clip.uri)
                val bmp = r.getScaledFrameAtTime(
                    clip.trimStartMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 240, 135
                )
                if (bmp != null) withContext(Dispatchers.Main) { thumbs[clip.id] = bmp.asImageBitmap() }
            } catch (_: Exception) {
            } finally {
                try { r.release() } catch (_: Exception) {}
            }
        }
    }

    fun addAudio(uri: Uri, name: String, isVoice: Boolean = false) {
        viewModelScope.launch {
            val dur = withContext(Dispatchers.IO) { readInfo(uri)?.first ?: 0L }
            if (dur <= 0L) { message = "Não foi possível abrir o áudio."; return@launch }
            commit()
            val item = AudioItem(nextId(), uri, name, dur, isVoice = isVoice)
            audios.add(item)
            selectAudio(item.id)
        }
    }

    // ---------- Edição de clipes ----------
    fun editClip(id: Long, structural: Boolean = false, f: (Clip) -> Clip) {
        val i = clips.indexOfFirst { it.id == id }
        if (i < 0) return
        if (structural) commit() else commitThrottled()
        clips[i] = f(clips[i])
    }

    fun setTrim(id: Long, startMs: Long, endMs: Long) {
        editClip(id) { it.copy(trimStartMs = startMs, trimEndMs = endMs) }
    }

    fun splitAtPlayhead() {
        var start = 0L
        for ((i, c) in clips.withIndex()) {
            val end = start + c.outDurationMs
            if (playheadMs in start..end) {
                val localOut = playheadMs - start
                val splitSource = c.trimStartMs + (localOut * c.speed).toLong()
                if (splitSource - c.trimStartMs < 300 || c.trimEndMs - splitSource < 300) {
                    message = "Posicione a linha vermelha no meio do clipe para dividir."
                    return
                }
                commit()
                val first = c.copy(trimEndMs = splitSource)
                val second = c.copy(id = nextId(), name = c.name + " (2)", trimStartMs = splitSource)
                clips[i] = first
                clips.add(i + 1, second)
                thumbs[c.id]?.let { thumbs[second.id] = it }
                loadThumb(second)
                selectClip(second.id)
                return
            }
            start = end
        }
        message = "Selecione um ponto sobre um clipe para dividir."
    }

    fun duplicateSelected() {
        val c = selectedClip ?: return
        commit()
        val i = clips.indexOfFirst { it.id == c.id }
        val copy = c.copy(id = nextId(), name = c.name + " (cópia)")
        clips.add(i + 1, copy)
        thumbs[c.id]?.let { thumbs[copy.id] = it }
        selectClip(copy.id)
    }

    fun moveSelected(dir: Int) {
        val i = clips.indexOfFirst { it.id == selectedClipId }
        val j = i + dir
        if (i < 0 || j !in clips.indices) return
        commit()
        val c = clips.removeAt(i)
        clips.add(j, c)
    }

    fun deleteSelected() {
        when {
            selectedTextId != null -> { commit(); texts.removeAll { it.id == selectedTextId }; selectedTextId = null }
            selectedAudioId != null -> { commit(); audios.removeAll { it.id == selectedAudioId }; selectedAudioId = null }
            selectedClipId != null -> {
                commit()
                val i = clips.indexOfFirst { it.id == selectedClipId }
                clips.removeAll { it.id == selectedClipId }
                selectedClipId = clips.getOrNull(i.coerceAtMost(clips.lastIndex))?.id
                playheadMs = playheadMs.coerceAtMost(totalMs)
            }
        }
    }

    // ---------- Textos e áudio ----------
    fun newText(text: String): TextItem {
        val start = playheadMs.coerceAtMost((totalMs - 500).coerceAtLeast(0))
        val end = (start + 3000).coerceAtMost(totalMs.coerceAtLeast(start + 500))
        return TextItem(nextId(), text, start, end)
    }

    fun upsertText(t: TextItem) {
        commit()
        val i = texts.indexOfFirst { it.id == t.id }
        if (i >= 0) texts[i] = t else texts.add(t)
        selectText(t.id)
    }

    /** Ajuste contínuo (slider de tempo do texto), sem criar um passo de desfazer a cada movimento. */
    fun upsertTextQuiet(t: TextItem) {
        val i = texts.indexOfFirst { it.id == t.id }
        if (i < 0) return
        commitThrottled()
        texts[i] = t
    }

    fun editAudio(id: Long, f: (AudioItem) -> AudioItem) {
        val i = audios.indexOfFirst { it.id == id }
        if (i < 0) return
        commitThrottled()
        audios[i] = f(audios[i])
    }

    // ---------- Gravação de voz ----------
    private var recorder: MediaRecorder? = null
    private var recFile: File? = null

    fun startRecording() {
        val ctx = getApplication<Application>()
        try {
            val f = File(ctx.cacheDir, "voz_${System.currentTimeMillis()}.m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128_000)
            r.setAudioSamplingRate(44_100)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            recFile = f
            recording = true
        } catch (e: Exception) {
            message = "Não foi possível iniciar a gravação."
            recording = false
        }
    }

    fun stopRecording() {
        val r = recorder ?: return
        recording = false
        try { r.stop() } catch (_: Exception) {}
        try { r.release() } catch (_: Exception) {}
        recorder = null
        val f = recFile ?: return
        if (f.length() > 0) {
            val n = audios.count { it.isVoice } + 1
            addAudio(Uri.fromFile(f), "Voz $n", isVoice = true)
        }
    }

    // ---------- Exportação ----------
    private var transformer: Transformer? = null
    private var pollJob: Job? = null

    fun startExport(s: ExportSettings) {
        if (clips.isEmpty()) { message = "Adicione um vídeo primeiro."; return }
        val ctx = getApplication<Application>()
        val ext = if (s.audioOnly) "m4a" else "mp4"
        val out = File(ctx.cacheDir, "export_${System.currentTimeMillis()}.$ext")
        try {
            val composition = ExportBuilder.build(clips.toList(), texts.toList(), audios.toList(), s)
            val encoder = DefaultEncoderFactory.Builder(ctx)
                .setRequestedVideoEncoderSettings(
                    VideoEncoderSettings.Builder().setBitrate(s.bitrate).build()
                )
                .setEnableFallback(true)
                .build()
            val t = Transformer.Builder(ctx)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(encoder)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        pollJob?.cancel()
                        viewModelScope.launch {
                            val uri = withContext(Dispatchers.IO) {
                                try { MediaSaver.saveToGallery(ctx, out, s.audioOnly) } catch (e: Exception) { null }
                            }
                            out.delete()
                            exportState = if (uri != null) {
                                ExportState.Done(
                                    if (s.audioOnly) "Áudio salvo em Música/EditorPro."
                                    else "Vídeo salvo na galeria (pasta Filmes/EditorPro)."
                                )
                            } else ExportState.Failed("Exportou, mas não consegui salvar na galeria.")
                        }
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        pollJob?.cancel()
                        out.delete()
                        exportState = ExportState.Failed(
                            "Falha na exportação: " + (exportException.message ?: "erro desconhecido")
                        )
                    }
                })
                .build()
            transformer = t
            exportState = ExportState.Running(0)
            t.start(composition, out.absolutePath)
            val holder = ProgressHolder()
            pollJob = viewModelScope.launch {
                while (isActive) {
                    val state = t.getProgress(holder)
                    if (state != Transformer.PROGRESS_STATE_NOT_STARTED &&
                        state != Transformer.PROGRESS_STATE_UNAVAILABLE
                    ) {
                        exportState = ExportState.Running(holder.progress)
                    }
                    delay(300)
                }
            }
        } catch (e: Exception) {
            exportState = ExportState.Failed("Não foi possível iniciar: " + (e.message ?: ""))
        }
    }

    fun cancelExport() {
        pollJob?.cancel()
        transformer?.cancel()
        exportState = ExportState.Idle
    }

    fun resetExport() { exportState = ExportState.Idle }

    override fun onCleared() {
        pollJob?.cancel()
        transformer?.cancel()
        try { recorder?.release() } catch (_: Exception) {}
        super.onCleared()
    }
}
